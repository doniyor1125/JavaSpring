package com.example.db_connect_wud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbConnectWudApplicationTests {

    @Test
    void contextLoads() {
    }

}
